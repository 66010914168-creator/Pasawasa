<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>พรรษวสา กวนขุนทด(บอม)</title>
</head>

<body>
<h1>พรรษวสา กวนขุนทด(บอม)</h1>

<script language="javascript">
	document.write("คณะการบัญชีการจัดการ");
</script>
<br>
<?php
	echo "Web Programming <br>";
    echo "Mahassarakham University <br>";
	print  "Pansawasa Khuankunthod<br>";
	
	$name="พรรษวสา กวนขุนทด";
	$age= 25.5;
	$Name="พรรษวสา กวนวนวน";
	
	//echo gettype($age);
	var_dump($age);
	echo "<hr>";
	
	echo $name."<br>";
	echo $Name."<hr>";
	
	$a=10;
	$b=5;
	$c=2;
	$x=($a+$b)*$c;
	echo $x;
?>
</body>
</html>