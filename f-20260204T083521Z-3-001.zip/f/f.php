<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>พรรษวสา กวนขุนทด (บอม)</title>
</head>

<body>
<h1>พรรษวสา กวนขุนทด (บอม)do -while<h1>
<?php
$i = 1;
do {
    echo "$i : พรรษวสา กวนขุนทด <br>";
    echo "<img src='1.jpg' width='250'><hr>";
    $i++;
} while ($i <= 10);
?>


</body>
</html>