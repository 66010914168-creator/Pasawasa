<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>พรรษวสา กวนขุนทด (บอม) - for</title>
</head>

<body>
<h1>พรรษวสา กวนขุนทด (บอม)-for</h1>

<?php
for($i = 1; $i <= 10; $i++) {
    echo "$i : พรรษวสา กวนขุนทด <br>";
    echo "<img src='1.jpg' width='250'> <hr>";
}
?>

</body>
</html>
